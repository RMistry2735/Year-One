Programming Portfolio Lab Work One
all files here are written in python (.py)
